import boto3
import json
import os
import logging
from datetime import datetime

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sns = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

def lambda_handler(event, context):
    environment = os.environ['ENVIRONMENT']
    topic_arn = os.environ['EMERGENCY_TOPIC_ARN']
    table_name = os.environ['ALERTS_TABLE_NAME']

    alert_id = context.aws_request_id
    timestamp = datetime.utcnow().isoformat()

    try:
        sns.publish(
            TopicArn=topic_arn,
            Message=json.dumps({
                'alert_id': alert_id,
                'timestamp': timestamp,
                'environment': environment,
                'payload': event
            }),
            Subject='EMERGENCY ALERT - MediCare+',
            MessageAttributes={
                'severity': {
                    'DataType': 'String',
                    'StringValue': event.get('severity', 'HIGH')
                }
            }
        )

        table = dynamodb.Table(table_name)
        table.put_item(Item={
            'alert_id': alert_id,
            'timestamp': timestamp,
            'status': 'SENT',
            'payload': json.dumps(event),
            'environment': environment
        })

        logger.info(f"Emergency alert {alert_id} sent successfully")
        return {'statusCode': 200, 'alert_id': alert_id}

    except Exception as e:
        logger.error(f"Failed to send emergency alert: {str(e)}")
        raise
