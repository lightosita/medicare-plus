import boto3
import json
import logging
import psycopg2
import secrets
import string

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    arn   = event['SecretId']
    token = event['ClientRequestToken']
    step  = event['Step']

    client = boto3.client('secretsmanager')
    meta   = client.describe_secret(SecretId=arn)

    if not meta.get('RotationEnabled'):
        raise ValueError(f"Rotation not enabled for {arn}")

    stages = meta.get('VersionIdsToStages', {})
    if token not in stages:
        raise ValueError(f"Token {token} not found in secret versions")

    if 'AWSCURRENT' in stages.get(token, []):
        logger.info("Version already current, nothing to do")
        return

    if step == "createSecret":
        _create_secret(client, arn, token)
    elif step == "setSecret":
        _set_secret(client, arn, token)
    elif step == "testSecret":
        _test_secret(client, arn, token)
    elif step == "finishSecret":
        _finish_secret(client, arn, token, stages)
    else:
        raise ValueError(f"Unknown step: {step}")

def _generate_password(length=32):
    alphabet = string.ascii_letters + string.digits + "!#$%&*()-_=+[]{}?"
    return ''.join(secrets.choice(alphabet) for _ in range(length))

def _create_secret(client, arn, token):
    try:
        client.get_secret_value(SecretId=arn, VersionStage='AWSPENDING',
                                VersionId=token)
        logger.info("Pending version already exists")
        return
    except client.exceptions.ResourceNotFoundException:
        pass

    current = json.loads(
        client.get_secret_value(SecretId=arn, VersionStage='AWSCURRENT')['SecretString']
    )
    current['password'] = _generate_password()

    client.put_secret_value(
        SecretId=arn,
        ClientRequestToken=token,
        SecretString=json.dumps(current),
        VersionStages=['AWSPENDING']
    )

def _set_secret(client, arn, token):
    pending = json.loads(
        client.get_secret_value(SecretId=arn, VersionStage='AWSPENDING',
                                VersionId=token)['SecretString']
    )
    current = json.loads(
        client.get_secret_value(SecretId=arn, VersionStage='AWSCURRENT')['SecretString']
    )

    conn = psycopg2.connect(
        host=current['host'], port=current['port'],
        dbname=current['dbname'], user=current['username'],
        password=current['password'], connect_timeout=5
    )
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute(
            "ALTER USER %s WITH PASSWORD %s",
            (pending['username'], pending['password'])
        )
    conn.close()

def _test_secret(client, arn, token):
    pending = json.loads(
        client.get_secret_value(SecretId=arn, VersionStage='AWSPENDING',
                                VersionId=token)['SecretString']
    )
    conn = psycopg2.connect(
        host=pending['host'], port=pending['port'],
        dbname=pending['dbname'], user=pending['username'],
        password=pending['password'], connect_timeout=5
    )
    conn.close()

def _finish_secret(client, arn, token, stages):
    current = [v for v, s in stages.items() if 'AWSCURRENT' in s]
    client.update_secret_version_stage(
        SecretId=arn,
        VersionStage='AWSCURRENT',
        MoveToVersionId=token,
        RemoveFromVersionId=current[0] if current else None
    )
